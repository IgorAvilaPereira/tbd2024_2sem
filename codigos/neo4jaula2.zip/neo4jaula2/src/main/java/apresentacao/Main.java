/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package apresentacao;

import negocio.Disciplina;
import org.neo4j.driver.AuthTokens;
import org.neo4j.driver.Driver;
import org.neo4j.driver.GraphDatabase;
import org.neo4j.driver.Result;
import org.neo4j.driver.Session;
import static org.neo4j.driver.Values.parameters;
import persistencia.DisciplinaDAO;

/**
 *
 * @author iapereira
 */
public class Main {
    
    public static void main(String[] args) {
        
        var disciplinaDAO = new DisciplinaDAO();
//        disciplinaDAO.deletarTudo();
        
//        Disciplina disciplinaNova = new Disciplina();
//        disciplinaNova.setHoras(100);
//        disciplinaNova.setNome("oisudjfiuosdjfiod");
//        disciplinaNova.setSemestre(10);
//        disciplinaNova.setSigla("oisdajfiosdjf");        
//        disciplinaDAO.inserir(disciplinaNova);

//        disciplinaDAO.deletar(42);
        
        disciplinaDAO.criarRelacionamento("nova_disciplina", "oisdajfiosdjf");
        disciplinaDAO.listar().forEach(p -> System.out.println(p));
        
    }
}
