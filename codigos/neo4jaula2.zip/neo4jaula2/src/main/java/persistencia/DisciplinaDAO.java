/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

import java.util.ArrayList;
import java.util.List;
import negocio.Disciplina;
import org.neo4j.driver.AuthTokens;
import org.neo4j.driver.Driver;
import org.neo4j.driver.GraphDatabase;
import static org.neo4j.driver.GraphDatabase.driver;
import org.neo4j.driver.Result;
import org.neo4j.driver.Session;
import org.neo4j.driver.Value;
import static org.neo4j.driver.Values.parameters;

/**
 *
 * @author iapereira
 */
public class DisciplinaDAO {

    private static final String URL = "bolt://localhost:7687";
    private static final String USERNAME = "neo4j";
    private static final String PASSWORD = "password";

    public Driver startDriver() {
        return GraphDatabase.driver(URL,
                AuthTokens.basic(USERNAME, PASSWORD));

    }

    public void inserir(Disciplina disciplina) {
        Driver driver = this.startDriver();
        try (Session session = driver.session()) {
            session.run("CREATE (d:Disciplina {semestre: $semestre, sigla: $sigla, nome: $nome, horas: toInteger($horas)});",
                    parameters(
                            "semestre", disciplina.getSemestre(),
                            "sigla", disciplina.getSigla(),
                            "nome", disciplina.getNome(),
                            "horas", disciplina.getHoras()));

        } finally {
            driver.close();
        }

    }

    public void deletar(int id) {
        Driver driver = this.startDriver();
        try (Session session = driver.session()) {
            session.run("MATCH (p) where ID(p) = $id DETACH DELETE p RETURN *", parameters("id", id));
        } finally {
            driver.close();
        }

    }

    public void deletarTudo() {
        Driver driver = this.startDriver();
        try (Session session = driver.session()) {
            session.run("MATCH (p) DETACH DELETE p RETURN *");
        } finally {
            driver.close();
        }

    }

    public ArrayList<Disciplina> listar() {
        ArrayList<Disciplina> vetDisciplina = new ArrayList();
        Driver driver = this.startDriver();
        try (Session session = driver.session()) {
            Result result = session.run("MATCH (p:Disciplina) RETURN p;");
            while (result.hasNext()) {
                Disciplina disciplina = new Disciplina();
                Value nodo = result.next().get(0);
//                System.out.println(nodo.asList(mapFunction).forEach(p -> System.out.println(p)));
//                disciplina.setId();
                disciplina.setSemestre(nodo.get("semestre").asInt());
                disciplina.setHoras(nodo.get("horas").asInt());
                disciplina.setSigla(nodo.get("sigla").asString());
                disciplina.setNome(nodo.get("nome").asString());
                vetDisciplina.add(disciplina);
            }
        } finally {
            driver.close();
        }
        return vetDisciplina;
    }

    public List<String> listarNomes() {
        List<String> vetNome = new ArrayList();
        Driver driver = this.startDriver();
        try (Session session = driver.session()) {
            Result result = session.run("MATCH (p:Disciplina) RETURN *");
            while (result.hasNext()) {
                vetNome.add(String.valueOf(result.next().get(0).get("nome")));
            }
        } finally {
            driver.close();
        }
        return vetNome;
    }
    
    public void criarRelacionamento(String sigla1, String sigla2) {
        String cypher = "MATCH (d1:Disciplina), (d2:Disciplina) where d1.sigla = $sigla1 and d2.sigla = $sigla2 "
                + "CREATE (d1)-[:PREREQUISITO]->(d2)";

        Driver driver = this.startDriver();
        try (Session session = driver.session()) {
            session.run(cypher, parameters("sigla1", sigla1, "sigla2", sigla2));

        } finally {
            driver.close();
        }
    }

    public void criarRelacionamento(int id1, int id2) {
        String cypher = "MATCH (d1:Disciplina), (d2:Disciplina) where ID(d1) = $id1 and ID(d2) = $id2 "
                + "CREATE (d1)-[:PREREQUISITO]->(d2)";

        Driver driver = this.startDriver();
        try (Session session = driver.session()) {
            session.run(cypher, parameters("id1", id1, "id2", id2));

        } finally {
            driver.close();
        }
    }
}
